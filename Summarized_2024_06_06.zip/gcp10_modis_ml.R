
# R packages that must be loaded at the beginning of the R session

if(!require(remotes)) install.packages("remotes");
if(!require(FeatureSelection)) {
  remotes::install_github(repo = "mlampros/FeatureSelection", dependencies = T, upgrade = T)
}

if(!require(pacman)) install.packages("pacman");
pacman::p_load(here,
               doParallel, 
               foreach,
               parallel,
               glue,
               data.table,
               theft, 
               stringr, 
               FeatureSelection,
               caret, 
               ranger, 
               tibble, 
               Metrics,
               ggplot2,
               install = TRUE)


# Default directory
def_dir = here::here()

# the data directory that includes the 'gcp10_met_data_2010_to_2020.csv' file and the folder 'rice_areas/GGCP10' (which has the GCP10 .tif files)
data_dir = file.path(def_dir, 'data')

# DIR_SAVE = '/media/lampros/USB STICK/RASTERS'         # use this path if hard drive does not have enough space
DIR_SAVE = file.path(data_dir, 'save_dir')
if (!dir.exists(DIR_SAVE)) stop(glue::glue("The directory '{DIR_SAVE}' is required!"))

# read the .csv file
dat_mod = data.table::fread(file = file.path(DIR_SAVE, 'gcp10_met_modis_2010_2020.csv'), stringsAsFactors = F, header = T)
dat_mod
dim(dat_mod)

# remove duplicated spatial pixels
not_dups = which(!duplicated(dat_mod[, c('year', 'X', 'Y')]))
dat_mod_subs = dat_mod[not_dups, , drop = F]

# split by 'X', 'Y'
dat_mod_subs_spl = split(dat_mod_subs, by = c('X', 'Y'))

# create the features for the following columns (exclude LAI_500m)
cols_use = c("aet", "def", "PDSI", "pet", "ppt", 
             "q", "soil", "srad", "tmax", "tmin", "vap", "vpd", "humidity", 
             "ws", "500m_16_days_EVI", "500m_16_days_NDVI", "500m_16_days_NIR_reflectance", 
             "500m_16_days_red_reflectance", "500m_16_days_blue_reflectance", 
             "sur_refl_b01", "sur_refl_b02", "sur_refl_b03", "sur_refl_b04", 
             "sur_refl_b05", "sur_refl_b06")

# iterate and create the summary features
dat_fts = lapply(seq_along(dat_mod_subs_spl), function(j) {
  
  cat("===============================================\n")
  cat(glue::glue("{j} / {length(dat_mod_subs_spl)}"), "\n")
  cat("===============================================\n")
  
  item_dat = dat_mod_subs_spl[[j]]
  
  item_dat$X = NULL
  item_dat$Y = NULL
  item_dat$id = j
  
  dtbl_lst = list()
  
  for (idx in seq_along(cols_use)) {
    
    cat(paste0(idx, '.'))
    COL = cols_use[idx] 
    
    fts_j = theft::calculate_features(data = item_dat,
                                      id_var = 'id',
                                      time_var = "year",
                                      values_var = COL,
                                      group_var = NULL,
                                      feature_set = c("catch22",
                                                      "feasts"),
                                      # "tsfresh"),
                                      catch24 = TRUE,
                                      tsfresh_cleanup = FALSE,
                                      features = NULL,
                                      seed = j)
    
    nams = fts_j$names
    nams = gsub(pattern = '["\\-]', replacement = '', x = nams)
    nams = glue::glue("{nams}_{fts_j$feature_set}_{COL}")
    
    dtbl = list(values = fts_j$values) |>
      data.table::setDT()
    
    dtbl = data.frame(matrix(fts_j$values, nrow = 1, ncol = length(nams))) |>
      data.table::as.data.table()
    colnames(dtbl) = nams
    dtbl_lst[[idx]] = dtbl
  }
  
  dtbl_lst_bnd = dplyr::bind_cols(dtbl_lst) |>
    data.table::as.data.table()
  
  dtbl_lst_bnd$rice_production = mean(item_dat$rice_production)
  
  dtbl_lst_bnd
})


# save the sublists
saveRDS(object = dat_fts, file = file.path(def_dir, 'dat_fts.RDS'))

# observe number of columns
table(as.vector(unlist(lapply(dat_fts, ncol))))
# 1150 1650 
#   12  263 

# Keep only sublists with the same number of columns
max_cols = max(as.vector(unlist(lapply(dat_fts, ncol))))
idx_keep = which(as.vector(unlist(lapply(dat_fts, function(x) ncol(x)))) == max_cols)
length(idx_keep)

dat_fts_subs = dat_fts[idx_keep]

# rbind same number of column sublists
dat_fts_rb = data.table::rbindlist(dat_fts_subs)
dim(dat_fts_rb)

# Remove columns which have NA's
idx_keep_notnan = which(as.vector(colSums(is.na(dat_fts_rb))) == 0)
length(idx_keep_notnan)

dat_fts_rb_keep = dat_fts_rb[, ..idx_keep_notnan]
dim(dat_fts_rb_keep)

RICE_PRODUCTION = dat_fts_rb_keep[['rice_production']]

rice_prod_col = which(stringr::str_detect(string = colnames(dat_fts_rb_keep), pattern = 'rice_production'))
x_keep = setdiff(x = 1:ncol(dat_fts_rb_keep), y = rice_prod_col)
X_COLS = dat_fts_rb_keep[, ..x_keep]

# use feature selection to avoid overfitting
params_glmnet = list(alpha = 1,
                     family = 'gaussian',
                     nfolds = 5,
                     parallel = FALSE)

# Feature selection function
res_fs = FeatureSelection::feature_selection(X = X_COLS,
                                             y = RICE_PRODUCTION,
                                             method = 'glmnet-lasso',
                                             params_glmnet = params_glmnet,
                                             CV_folds = 5,
                                             cores_glmnet = 1,
                                             verbose = TRUE)
res_fs


# keep the columms
nams_keep = res_fs$Feature
X_COLS_keep = X_COLS[, ..nams_keep]

# hyper parameter tuning
bst_caret_models = function(x,    # the input data
                            y,
                            ml_model,
                            grid_params,
                            tuneLength = 20) {
  
  if (ml_model == 'ranger') {
    
    tune_caret = caret::train(x = x,
                              y = y,
                              method = ml_model,
                              # preProcess = c('center', 'scale'),                  # center and scale the predictors
                              metric = "RMSE",                                # Accuracy is used to decide on the model performance
                              tuneLength = tuneLength,
                              tuneGrid = grid_params,
                              # num.trees = 1000,                                 # I have to specify the number of trees for the 'ranger' algorithm
                              num.trees = 500,
                              trControl = caret::trainControl(method = 'cv',
                                                              number = 5,
                                                              allowParallel = TRUE))     # use a 5-fold cross validation and allow parallelization if available
  }
  
  return(tune_caret)
}


# grid for the ranger algorithm
grid_params_mods = list(ranger = expand.grid(.mtry = c(4:6),
                                             .splitrule = c("variance", "extratrees"),
                                             .min.node.size = seq(1, 10, 2)))

# hyper parameter tuning using the grid
rf_fit = bst_caret_models(x = X_COLS_keep,        
                          y = RICE_PRODUCTION,
                          ml_model = 'ranger',                            # the input model
                          grid_params = grid_params_mods[['ranger']],     # the grid of parameters for the input model
                          tuneLength = 5)                                   # use the 'bst_caret_models' function

# The results table
rf_results = rf_fit$results                                                 # keep the results and order these by accuracy
rf_results = rf_results[order(rf_results$RMSE, decreasing = F), ]
rf_results

# The best parameters
bst_params = rf_fit$bestTune 
bst_params

# cross validation folds
folds_k = 5

set.seed(1)
FOLDS = caret::createFolds(y = RICE_PRODUCTION, k = folds_k, list = TRUE)
str(FOLDS)

threads = 3
test_preds_lst = feature_imp = list()
rmse_rf = rep(NA_real_, folds_k)
preds_out = list()

# iterate over the cross-validation folds
for (j in 1:(length(FOLDS))) {
  
  cat(paste0(j, '.'))
  train_idxs = as.vector(unlist(FOLDS[-j]))
  test_idxs = FOLDS[[j]]
  
  fit_rng = ranger::ranger(x = X_COLS_keep[train_idxs, , drop = F], 
                           y = RICE_PRODUCTION[train_idxs],
                           num.trees = 1500, 
                           mtry = bst_params$mtry, 
                           importance = 'permutation',
                           splitrule = as.character(bst_params$splitrule),
                           min.node.size = bst_params$min.node.size,
                           classification = FALSE,
                           verbose = TRUE,
                           num.threads = threads)
  
  imp_mod_iter = ranger::importance(fit_rng)
  dtbl_features = tibble::enframe(imp_mod_iter, name = "variable", value = "importance") |>
    data.table::as.data.table()
  
  preds_test = predict(object = fit_rng, 
                       data = X_COLS_keep[test_idxs, , drop = F], 
                       num.threads = threads)$predictions
  
  t_preds_dtbl = list(true = RICE_PRODUCTION[test_idxs],
                      preds = preds_test,
                      fold = rep(j, length(preds_test))) |>
    data.table::setDT()

  test_preds_lst[[j]] = t_preds_dtbl
  
  feature_imp[[j]] = dtbl_features
  rmse_rf[j] = Metrics::rmse(actual = RICE_PRODUCTION[test_idxs], predicted = preds_test)
}


# root mean squared error
lst_rmse_res = list(fold = glue::glue("fold_{1:folds_k}"),
                    RMSE = rmse_rf) |>
  data.table::setDT()

cat(glue::glue("Average RMSE: {mean(lst_rmse_res$RMSE)}"), '\n')

# save the RMSE table
data.table::fwrite(x = lst_rmse_res, file = file.path(def_dir, 'RMSE_folds.csv'), row.names = F)

# save the predictions per fold
test_preds_lst = data.table::rbindlist(test_preds_lst)
data.table::fwrite(x = test_preds_lst, file = file.path(def_dir, 'predictions_folds.csv'), row.names = F)

# save feature importance
# Visualize the feature importance
dtbl_all = data.table::rbindlist(feature_imp)
dtbl_all = dtbl_all[, .(importance = mean(importance)), by = 'variable']
dtbl_all = dtbl_all[order(dtbl_all$importance, decreasing = T), ]

# save the feature importance .csv file
data.table::fwrite(x = dtbl_all, file = file.path(def_dir, "feature_importance.csv"), row.names = F)

plt = ggplot2::ggplot(dtbl_all,
                      ggplot2::aes(x = reorder(variable, importance), y = importance, fill = importance)) +
  ggplot2::geom_bar(stat = "identity", position = "dodge") +
  ggplot2::coord_flip() +
  ggplot2::ylab("Variable Importance") +
  ggplot2::xlab("") +
  ggplot2::ggtitle("Feature Importance") +
  ggplot2::guides(fill = "none") +
  ggplot2::scale_fill_gradient(low = "red", high = "blue")

# save the feature importance plot
ggplot2::ggsave(filename = file.path(def_dir, "feature_importance_plot.png"), plot = plt, width = 15, height = 10)


