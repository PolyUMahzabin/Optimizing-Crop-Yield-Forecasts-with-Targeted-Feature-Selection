
# R packages that must be loaded at the beginning of the R session
if(!require(pacman)) install.packages("pacman");
pacman::p_load(here,
               sf,
               terra,
               doParallel, 
               foreach,
               parallel,
               glue,
               data.table,
               bangladesh,
               rstac,
               spatialEco,
               fst,
               Hmisc,
               utils,
               withr,
               lwgeom,
               install = TRUE)


# This parameter is important, otherwise the API-service will become stall (will not progress). If there is no progress in 
# downloading then increase this value. Currently the default value of delay is 2 minutes (or 120 seconds) per call to the "rstac::stac_search()" function
DELAY_call_API = 120

# Default directory
def_dir = here::here()

# the data directory that includes the 'gcp10_met_data_2010_to_2020.csv' file and the folder 'rice_areas/GGCP10' (which has the GCP10 .tif files)
data_dir = file.path(def_dir, 'data')

# DIR_SAVE = '/media/lampros/USB STICK/RASTERS'         # use this path if hard drive does not have enough space
DIR_SAVE = file.path(data_dir, 'save_dir')
if (!dir.exists(DIR_SAVE)) dir.create(DIR_SAVE)

# create a temporary directory to save the files
temp_save_dir = file.path(DIR_SAVE, 'temp_dir')
if (!dir.exists(temp_save_dir)) dir.create(temp_save_dir)

# file path for the saved projections of each product
FILE_proj = file.path(DIR_SAVE, 'projections.RDS')

# read the gcp10_met_data_2010_to_2020.csv' file
dat = data.table::fread(file = file.path(data_dir, 'gcp10_met_data_2010_to_2020.csv'), header = T, stringsAsFactors = F)
dat

# load also the Geometries of the "gcp10_met_data_2010_to_2020.csv" file
dat_geoms = data.table::fread(file = file.path(data_dir, 'gcp10_met_data_2010_to_2020_GEOMETRIES.csv'), header = T, stringsAsFactors = F, sep = '\t')
# dat_geoms

# add the geometry column to the data
dat$geometry = dat_geoms$geom

# convert the geoms to an 'sf' object
dat_sf = sf::st_as_sf(dat, wkt = 'geometry', crs = 4326)

#=============================================================================== get the dhaka division

# load the 'dhaka' division
dhaka_division = bangladesh::map_division |>
  subset(Division == 'Dhaka')

sf_union = sf::st_union(dhaka_division$geometry)
# mapview::mapview(sf_union)

# the bounding box to use to get the sentinel data
sf_union_bbx = sf::st_bbox(sf_union)
# mapview::mapview(sf_union) + mapview::mapview(sf_union_bbx)

unq_years = unique(dat$year)
unq_years


# download function  [ getOption("timeout")  returns 60 and it was set up to 600 (see: https://github.com/mlverse/torchdatasets/blob/master/R/utils.R#L20) ]
download_file <- function(url, 
                          destfile,
                          timeout = 600) {
  
  withr::with_options(new = list(timeout = max(timeout, getOption("timeout"))), {
    utils::download.file(url, destfile)
  })
}

#================================================================================================================================================================= Quality Assurance

# modis products to use
modis_products = list(Vegetation_Indices_16_Day = "modis-13A1-061",              # https://planetarycomputer.microsoft.com/dataset/modis-13A1-061#overview
                      Leaf_Area_Index_FPAR_8_Day = "modis-15A2H-061",            # https://planetarycomputer.microsoft.com/dataset/modis-15A2H-061#overview
                      Surface_Reflectance_8_Day = "modis-09A1-061")              # https://planetarycomputer.microsoft.com/dataset/modis-09A1-061#overview  

# names of products
nams = names(modis_products)
len_mod = length(nams)

# before downloading the MODIS data I have to check if the .fst files exist in the save directory
lst_fst = list.files(path = temp_save_dir, pattern = '.fst$', recursive = T)

if (length(lst_fst) == 0) {
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ "Vegetation_Indices_16_Day" Product  [ Mask Out QA values ]
  # ref. https://gis.stackexchange.com/a/330906/147911
  #      https://github.com/jeffreyevans/spatialEco/blob/master/R/parse.bits.R
  #      https://lpdaac.usgs.gov/documents/926/MOD15_User_Guide_V61.pdf                                    [ Use the "Table 5" in page 9/14 for reference to tell which pixels are of bad quality]
  #
  # Alternative using the "phenofit" R package:
  # https://github.com/eco-hydro/phenofit/blob/master/R/qcFUN.R#L129  [ "qc_FparLai()" ]
  # https://github.com/eco-hydro/phenofit/blob/master/R/qcFUN.R#L50   [ "getBits()" ]
  #.................................................................................. 
  
  # create the QC-bits for the pixels from 0 to 255 as mentioned also in the .pdf related file of the LAI product
  qc_bits = list(int=0:255,
                 modland_qc = unlist(lapply(0:255, FUN = spatialEco::parse.bits, bit = 0)),
                 sensor = unlist(lapply(0:255, FUN = spatialEco::parse.bits, bit = 1)),
                 dead_detector = unlist(lapply(0:255, FUN = spatialEco::parse.bits, bit = 2)),
                 cloud_state = unlist(lapply(0:255, FUN = spatialEco::parse.bits, bit = c(3,4))),
                 scf_qc = unlist(lapply(0:255, FUN = spatialEco::parse.bits, bit = c(5,6,7)))) |>
    data.table::setDT()
  
  # https://lpdaac.usgs.gov/documents/926/MOD15_User_Guide_V61.pdf    [ Use the "Table 5" in page 9/14 for reference to specify which pixels are of good quality so that I can keep the subset of each downloaded image ]
  #
  qc_bits_valid = subset(qc_bits, modland_qc == 0 & dead_detector == 0 & cloud_state %in% c("0 0", "1 1") & scf_qc %in% c("0 0 0", "0 0 1"))
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ "Surface Reflectance"
  # ref. https://lpdaac.usgs.gov/documents/925/MOD09_User_Guide_V61.pdf  [ page 25/36 , table 13 ]
  
  vec_refl = c(0:57343, 65535)
  qc_bits_refl = list(int = vec_refl,
                      cloud_state = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = c(0,1), depth = 16)),
                      cloud_shadow = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 2, depth = 16)),
                      land_water_flag = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = c(3,4,5), depth = 16)),
                      aerosol_quantity = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = c(6,7), depth = 16)),
                      cirrus_detected = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = c(8,9), depth = 16)),
                      internal_cloud_algo_flag = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 10, depth = 16)),
                      internal_fire_algo_flag = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 11, depth = 16)),
                      snow_ice_flag = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 12, depth = 16)),
                      pixel_adj_to_cloud = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 13, depth = 16)),
                      salt_pan = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 14, depth = 16)),
                      internal_snow_mask = unlist(lapply(vec_refl, FUN = spatialEco::parse.bits, bit = 15, depth = 16))) |>
    data.table::setDT()
  
  # omit anything related to clouds
  qc_bits_refl_valid = subset(qc_bits_refl, cloud_state %in% c("0 0", "1 1") & cloud_shadow == 0 & internal_cloud_algo_flag == 0 & pixel_adj_to_cloud == 0)
  
  #=================================================================================================================================================================
  
  #....................................................................... create a grid for the months and years between November and May
  months_year = 1:12
  dtbl_grid = list(year = sort(rep(unq_years, length(months_year)))) |>
    data.table::setDT()
  
  dtbl_grid$month = rep(months_year, length(unq_years))
  dtbl_grid = subset(dtbl_grid, month %in% c(11:12, 1:5))
  dtbl_grid$concat = glue::glue("{dtbl_grid$year}_{dtbl_grid$month}")
  
  # start from 11-2010 and end 05-2020
  idx_grid_keep = which(dtbl_grid$concat == '2010_11'):which(dtbl_grid$concat == '2020_5')
  dtbl_grid = dtbl_grid[idx_grid_keep, , drop = F]
  # dtbl_grid
  nrow_grid = nrow(dtbl_grid)
  #.......................................................................
  
  # modis product image bands to keep
  image_bands = list(Vegetation_Indices_16_Day = c("500m_16_days_NDVI", 
                                                   "500m_16_days_EVI",
                                                   "500m_16_days_pixel_reliability",
                                                   # "500m_16_days_VI_Quality",             # omit this image band but it might become too difficult to decide about quality between multiple vegetation indices, and use the "500m_16_days_pixel_reliability" instead
                                                   "500m_16_days_NIR_reflectance",
                                                   "500m_16_days_red_reflectance",
                                                   "500m_16_days_blue_reflectance"),
                     Leaf_Area_Index_FPAR_8_Day = c("Lai_500m", "FparLai_QC"),
                     Surface_Reflectance_8_Day = c('sur_refl_b01',
                                                   'sur_refl_b02',
                                                   'sur_refl_b03',
                                                   'sur_refl_b04',
                                                   'sur_refl_b05',
                                                   'sur_refl_b06',
                                                   'sur_refl_b07',
                                                   # 'sur_refl_qc_500m',
                                                   'sur_refl_state_500m'))
  
  # I have to save also the projections of the products
  projection_products = list(Vegetation_Indices_16_Day = NULL,
                             Leaf_Area_Index_FPAR_8_Day = NULL,
                             Surface_Reflectance_8_Day = NULL) 
  
  
  # url for the modis data
  stac_url = "https://planetarycomputer.microsoft.com/api/stac/v1"
  
  error_lst = list()
  count_error = 1
  
  # iterate over the products
  for (idx_mod in 1:len_mod) {
    
    cat("=======================================================================\n")
    cat(glue::glue("'{nams[idx_mod]}' product ( {nrow_grid} dates will be processed ) ..."), '\n')
    
    veg_dir = file.path(temp_save_dir, nams[idx_mod])
    if (!dir.exists(veg_dir)) dir.create(veg_dir)
    
    # iterate over the dates
    for (row_idx in 1:nrow_grid) {
      
      cat(paste0(row_idx, '.'))
      
      grid_dir = file.path(veg_dir, row_idx)
      if (!dir.exists(grid_dir)) dir.create(grid_dir)
      
      row_grid = dtbl_grid[row_idx, , drop = F]
      YEAR = row_grid$year
      MONTH = ifelse(nchar(row_grid$month) == 1, glue::glue("0{row_grid$month}"), as.character(row_grid$month))
      DAY_END = Hmisc::monthDays(time = as.Date(glue::glue("{YEAR}-{MONTH}-01")))
      
      # we have to make sure that we perform a call to the stac every 60 seconds
      t_call_start = proc.time()
      
      urls_cog = rstac::stac(base_url = stac_url) |>
        rstac::stac_search(collections = modis_products[[nams[idx_mod]]],
                           datetime = glue::glue("{YEAR}-{MONTH}-01/{YEAR}-{MONTH}-{DAY_END}"),
                           bbox = as.vector(sf_union_bbx),
                           limit = 85) |>
        rstac::post_request() |>
        rstac::assets_select(asset_names = image_bands[[nams[idx_mod]]]) |>
        rstac::items_sign(sign_fn = rstac::sign_planetary_computer())
      
      # get the features
      fts = urls_cog$features
      
      # iterate over the features
      for (j in seq_along(fts)) {
        
        dat = fts[[j]]
        
        ASSETS = dat$assets
        nams_dat = names(ASSETS)
        len_nams = length(nams_dat)
        
        fts_dir = file.path(grid_dir, j)
        if (!dir.exists(fts_dir)) dir.create(fts_dir)
        
        threads = ifelse(len_nams > parallel::detectCores(), parallel::detectCores(), len_nams)
        
        # OS specific code snippets
        if (.Platform$OS.type == "unix") {
          doParallel::registerDoParallel(cores = threads)
        }
        if (.Platform$OS.type == "windows") {
          cl = parallel::makePSOCKcluster(threads)
          doParallel::registerDoParallel(cl = cl)
        }
        
        par_downl = foreach::foreach(nam_idx = 1:len_nams) %dopar% {
          
          NAM_href = nams_dat[nam_idx]
          URL_DOWNL = ASSETS[[NAM_href]]$href
          file_out = file.path(fts_dir, glue::glue("{NAM_href}.tif"))
          
          download_file(url = URL_DOWNL, 
                        destfile = file_out, 
                        timeout = 600)
          file_out
        }
        
        if (.Platform$OS.type == "windows") {
          parallel::stopCluster(cl = cl)
        }
        
        # Unlist the .tif files
        FILES_TIF = unlist(par_downl)
        
        # load the raster data
        rst_j = terra::rast(FILES_TIF)
        names(rst_j) = nams_dat
        crs_rst_j = terra::crs(rst_j, proj = TRUE)
        
        if (is.null(projection_products[[nams[idx_mod]]])) {
          projection_products[[nams[idx_mod]]] = crs_rst_j
        }
        
        # transform the CRS of the sf object to match the CRS of the terra raster
        sf_union_transf = sf::st_transform(sf_union, crs = crs_rst_j)
        
        # convert the sf to terra vector
        ter_vec = terra::vect(sf_union_transf)
        
        # crop the raster data to the extent of the GCP10 area and make sure we don't receive an error if the Dhaka district geometry (which is smaller than the bounding box) doesn't intersect with the raster file
        rst_crp = tryCatch(terra::crop(x = rst_j, 
                                       y = ter_vec, 
                                       mask = TRUE, 
                                       overwrite = TRUE),  error = function(e) e)
        
        if (!inherits(rst_crp, 'error')) {
          
          rst_crp_dtbl = data.table::as.data.table(rst_crp, xy = T, na.rm = T)
          coord_nams = c('x', 'y')
          
          if (nrow(rst_crp_dtbl) > 0) {
            
            if ("Lai_500m" %in% nams_dat) {
              
              NAME = "Lai_500m"
              # subset the extracted pixels using the valid qc-bits
              rst_crp_dtbl_valid = subset(rst_crp_dtbl, FparLai_QC %in% qc_bits_valid$int)
              
              # add metadata
              coord_nams = c(coord_nams, NAME)
              rst_crp_dtbl_valid = rst_crp_dtbl_valid[, ..coord_nams]
              # colnames(rst_crp_dtbl_valid)[which(colnames(rst_crp_dtbl_valid) == NAME)] = 'values'
              # rst_crp_dtbl_valid$dataset = ASSETS[[NAME]]$title
              rst_crp_dtbl_valid$collection = dat$collection
              rst_crp_dtbl_valid$start_date = as.Date(dat$properties$start_datetime)
              rst_crp_dtbl_valid$end_date = as.Date(dat$properties$end_datetime)
              
              # save to compressed .fst file
              fst_file_name = glue::glue("{ASSETS[[NAME]]$title}_{dat$collection}_{as.character(as.Date(dat$properties$start_datetime))}_{as.character(as.Date(dat$properties$end_datetime))}_iter_{j}.fst")
              fst_file_name = gsub(pattern = ' ', replacement = '_', x = fst_file_name)
              
              pth_j = file.path(fts_dir, fst_file_name)
              fst::write_fst(x = rst_crp_dtbl_valid, path = pth_j, compress = 100)
              
            } else if (all(c("500m_16_days_EVI",
                             "500m_16_days_NDVI",
                             "500m_16_days_NIR_reflectance", 
                             "500m_16_days_red_reflectance", 
                             "500m_16_days_blue_reflectance",
                             "500m_16_days_pixel_reliability") %in% nams_dat)) {
              
              NAME = c("500m_16_days_EVI",
                       "500m_16_days_NDVI",
                       "500m_16_days_NIR_reflectance", 
                       "500m_16_days_red_reflectance", 
                       "500m_16_days_blue_reflectance")
              
              # update the image band pixel values using the "scale"
              for (name_veg in NAME) {
                # rescale the relevant columns
                SCALE = ASSETS[[name_veg]]$`raster:bands`[[1]]$scale
                rst_crp_dtbl[[name_veg]] = rst_crp_dtbl[[name_veg]] * SCALE                           # For the valid range see the "Layers/Variables" in https://lpdaac.usgs.gov/products/mod13a1v061/
              }
              
              # based on Page 17/33 [ https://lpdaac.usgs.gov/documents/621/MOD13_User_Guide_V61.pdf ]
              #
              # Rank Key       Summary     QA Description
              #       -1  Fill/No Data     Not Processed
              #        0     Good Data     Use with confidence
              #        1 Marginal data     Useful,but look at other QA information
              #        2      Snow/Ice     Target covered with snow/ice
              #        3        Cloudy     Target not visible, covered with cloud
              #
              # we'll keep pixel with value c(0,1,2)
              rst_crp_dtbl_valid = subset(rst_crp_dtbl, `500m_16_days_pixel_reliability` %in% c(0,1,2))
              
              # add metadata
              coord_nams = c(coord_nams, NAME)
              rst_crp_dtbl_valid = rst_crp_dtbl_valid[, ..coord_nams]
              # rst_crp_dtbl_valid$dataset = ASSETS[[NAME]]$title
              rst_crp_dtbl_valid$collection = dat$collection
              rst_crp_dtbl_valid$start_date = as.Date(dat$properties$start_datetime)
              rst_crp_dtbl_valid$end_date = as.Date(dat$properties$end_datetime)
              
              # save to compressed .fst file
              fst_file_name = glue::glue("500m_Vegetation_Indices_{dat$collection}_{as.character(as.Date(dat$properties$start_datetime))}_{as.character(as.Date(dat$properties$end_datetime))}_iter_{j}.fst")
              fst_file_name = gsub(pattern = ' ', replacement = '_', x = fst_file_name)
              
              pth_j = file.path(fts_dir, fst_file_name)
              fst::write_fst(x = rst_crp_dtbl_valid, path = pth_j, compress = 100)
              
            }  else if (all(c("sur_refl_b01", 
                              "sur_refl_b02",
                              "sur_refl_b03",
                              "sur_refl_b04", 
                              "sur_refl_b05",
                              "sur_refl_b06",
                              "sur_refl_b07") %in% nams_dat)) {
              
              NAME = c("sur_refl_b01", 
                       "sur_refl_b02",
                       "sur_refl_b03",
                       "sur_refl_b04", 
                       "sur_refl_b05",
                       "sur_refl_b06")
              
              #........................................................................ The 'scale' parameter does not apply here as the values seem to be scaled between 0.0 and 1.0 [ we tried this with more than 1 subsets ]
              # # update the image band pixel values using the "scale"
              # for (name_veg in NAME) {
              #   # rescale the relevant columns
              #   SCALE = ASSETS[[name_veg]]$`raster:bands`[[1]]$scale
              #   rst_crp_dtbl[[name_veg]] = rst_crp_dtbl[[name_veg]] * SCALE                           # For the valid range see the "Layers/Variables" in https://lpdaac.usgs.gov/products/mod13a1v061/
              # }
              #........................................................................
              
              # we'll keep pixel using the initially computed "qc_bits_refl_valid" R object
              rst_crp_dtbl_valid = subset(rst_crp_dtbl, sur_refl_state_500m %in% unique(qc_bits_refl_valid$int))
              
              # add metadata
              coord_nams = c(coord_nams, NAME)
              rst_crp_dtbl_valid = rst_crp_dtbl_valid[, ..coord_nams]
              # rst_crp_dtbl_valid$dataset = ASSETS[[NAME]]$title
              rst_crp_dtbl_valid$collection = dat$collection
              rst_crp_dtbl_valid$start_date = as.Date(dat$properties$start_datetime)
              rst_crp_dtbl_valid$end_date = as.Date(dat$properties$end_datetime)
              
              # save to compressed .fst file
              fst_file_name = glue::glue("Surface_Reflectance_{dat$collection}_{as.character(as.Date(dat$properties$start_datetime))}_{as.character(as.Date(dat$properties$end_datetime))}_iter_{j}.fst")
              fst_file_name = gsub(pattern = ' ', replacement = '_', x = fst_file_name)
              
              pth_j = file.path(fts_dir, fst_file_name)
              fst::write_fst(x = rst_crp_dtbl_valid, path = pth_j, compress = 100)
            }
          }
        } else {
          
          if ("Lai_500m" %in% nams_dat) {
            NAME = "Lai_500m"
            file_name = glue::glue("{ASSETS[[NAME]]$title}_{dat$collection}_{as.character(as.Date(dat$properties$start_datetime))}_{as.character(as.Date(dat$properties$end_datetime))}")
          }
          
          error_lst[[count_error]] = file_name
          count_error = count_error + 1
        }
        
        # remove the .tif files
        for (item_file in FILES_TIF) {
          file.remove(item_file)
        }
        
        #................................................................... visualize
        # ext_j = terra::ext(rst_j) |>
        #   sf::st_bbox() |>
        #   sf::st_as_sfc()
        # 
        # sf::st_crs(ext_j) <- sf::st_crs(crs_rst_j)
        # 
        # mapview::mapview(ext_j) + mapview::mapview(sf_union_transf)
        #...................................................................
      }
      
      t_call_end = proc.time()
      seconds_elapsed = as.numeric((t_call_end - t_call_start)['elapsed'])
      
      if (seconds_elapsed <= DELAY_call_API) {
        Sys.sleep(time = (DELAY_call_API - seconds_elapsed) + 1)     # make sure to call the API after a minute (or longer if I observe that the download does not progresses)
      }
    }
  }
}


# save the projections of each product
if (!file.exists(FILE_proj)) {
  saveRDS(object = projection_products, file = FILE_proj)
} else {
  projection_products = readRDS(file = FILE_proj)
}

# #=============================================================================== use the GCP10 data to get the spatial pixels 

# there are multipolygons which I have to cast to POLYGONS
types_geoms = sf::st_geometry_type(dat_sf) |>
  as.character()

# table(types_geoms)

idx_mltplg = which(types_geoms == 'MULTIPOLYGON')

if (length(idx_mltplg) > 0) {

  geoms_plg = dat_sf[-idx_mltplg, ] |>
    data.table::as.data.table()

  geoms_mlt_plg = dat_sf[idx_mltplg, ] 

  geoms_mlt_plg = sf::st_cast(x = geoms_mlt_plg, "MULTIPOLYGON") |>
    sf::st_cast("POLYGON") |>
    data.table::as.data.table()

  # once converted overwrite the previous object
  unq_geoms = rbind(geoms_plg, geoms_mlt_plg) |>
    sf::st_as_sf()
}

#=============================================================================== create an ID column so that we can merge the geometries inside the for-loop

GEOMS_ID = sf::st_geometry(unq_geoms) |>
  lwgeom::st_astext() 

unq_geoms$geom_txt = GEOMS_ID

unq_GEOMS_ID = unique(GEOMS_ID)

GEOMS_ID = list(geom_txt = unq_GEOMS_ID, 
                ID = 1:length(unq_GEOMS_ID)) |>
  data.table::setDT()

unq_geoms = merge(x = unq_geoms, y = GEOMS_ID, by = 'geom_txt')
unq_geoms$geom_txt = NULL

#=============================================================================== load all compressed .fst files for all 3 MODIS products

lst_all_out = list()

# iterate over the products
for (idx_mod in 1:len_mod) {
  
  cat("=======================================================================\n")
  cat(glue::glue("'{nams[idx_mod]}' saved product will be processed ..."), '\n')
  
  veg_dir = file.path(temp_save_dir, nams[idx_mod])
  if (!dir.exists(veg_dir)) stop(glue::glue("The required directory '{veg_dir}' does not exist!"))
  
  lst_tmp_veg_dir = list.files(path = veg_dir, pattern = '.fst$', full.names = TRUE, recursive = TRUE)
  
  # release ram 
  for (i in 1:10) {
    gc()
  }
  
  # iterate and load each one of the .fst files and then rbind() all data.tables
  dat_veg_dir = lapply(seq_along(lst_tmp_veg_dir), function(x) {
    dat_item = fst::read_fst(path = lst_tmp_veg_dir[x], as.data.table = TRUE)
  }) |>
    data.table::rbindlist()
  
  nrow_before = nrow(dat_veg_dir)
  
  # keep collection name
  collection_name = unique(dat_veg_dir$collection)
  if (length(collection_name) != 1) stop("I expect a single MODIS collection!")
  
  # add the year column based on the "start_date" column
  dat_veg_dir$year = lubridate::year(dat_veg_dir$start_date)
  
  # exclude columns
  cols_exclude = c("collection", "start_date", "end_date")
  dat_veg_dir = dat_veg_dir[, !..cols_exclude]
  
  # aggregate by the 'x', 'y' coordinates only
  cols_aggregate = c("x", "y", "year")
  dat_veg_dir = dat_veg_dir[, lapply(.SD, mean), by = cols_aggregate]

  # release ram 
  for (i in 1:10) {
    gc()
  }
  
  cat(glue::glue("The rbinded object has {nrow_before} rows and after aggregating by the 'x', 'y', 'collection', 'start_date', 'end_date' it has {nrow(dat_veg_dir)} rows!"), '\n')
  
  # create an sf object of the data
  dat_veg_dir_sf = sf::st_as_sf(dat_veg_dir,
                                coords = cols_aggregate[1:2],                       # use only the first 2 items, i.e. "x", "y"
                                crs = projection_products[[nams[idx_mod]]]) |>
    sf::st_transform(crs = sf::st_crs(unq_geoms))
  
  # make the transformed points valid
  dat_veg_dir_sf = sf::st_make_valid(dat_veg_dir_sf)
  
  # keep only the point geometries
  idx_point = which(sf::st_geometry_type(dat_veg_dir_sf$geometry) == 'POINT')
  dat_veg_dir_sf = dat_veg_dir_sf[idx_point, , drop = F]
  
  # iterate over the years and then preform the aggregation
  years_gcp_met = sort(unique(unq_geoms$year))
  years_modis = sort(unique(dat_veg_dir_sf$year))
  if (!all(years_gcp_met == years_modis)) stop("The years between the met-gcp10 and modis data must match!")
  
  joined_pnts = list()
  
  for (yr in years_gcp_met) {
    cat(paste0(yr, '.'))
    
    s_gcp_met = subset(unq_geoms, year == yr)
    s_modis = subset(dat_veg_dir_sf, year == yr)
    s_modis$year = NULL                             # Remove the year of the modis data
    
    # join the POINTS with the POLYGONS if the POINTS are contained in the POLYGONS (here we have duplicated POLYGON geometries which means the same multiple POINTS will be contained in more than one POLYGONS)
    joined_points = sf::st_join(x = s_gcp_met, 
                                y = s_modis,
                                join = sf::st_contains,
                                left = TRUE)
    
    # drop geometry and convet to data.table
    joined_points = sf::st_drop_geometry(joined_points) |>
      data.table::as.data.table()
    
    # aggregate the columns by the geometry column
    joined_points = joined_points[, lapply(.SD, mean, na.rm = TRUE), by = c('ID', 'year')]
    joined_pnts[[as.character(yr)]] = joined_points
  }
  
  # rbind() all years
  joined_pnts = data.table::rbindlist(joined_pnts)
  
  # save the output of the iterations item to a list
  lst_all_out[[idx_mod]] = joined_pnts
  
  # release ram 
  for (i in 1:10) {
    gc()
  }
}

#=============================================================================== finally merge all sublists by the geometry column

EXCLUDE_COLS = c("rice_production", "aet", "def", "PDSI", "pet", "ppt", "q", "soil", "srad", 
                 "tmax", "tmin", "vap", "vpd", "humidity", "ws", "X", "Y")

dtbl_merged = NULL

for (s in seq_along(lst_all_out)) {
  
  proc_dtbl = lst_all_out[[s]]
  
  if (s > 1) {
    proc_dtbl = proc_dtbl[, !..EXCLUDE_COLS]
  }
  
  if (is.null(dtbl_merged)) {
    dtbl_merged = proc_dtbl
  } else {
    dtbl_merged = merge(x = dtbl_merged, y = proc_dtbl, by = c('ID', 'year'))
  }
}


# save the .csv file
data.table::fwrite(x = dtbl_merged[, !'ID'], file = file.path(DIR_SAVE, 'gcp10_met_modis_2010_2020.csv'), row.names = F)

# use the previously created "GEOMS_ID" to replace the ID with the geometry column
dtbl_merged = merge(x = dtbl_merged, y = GEOMS_ID, by = 'ID')

# write the .shp file
# rename columns so that we have unique column names in the .shp file because the truncation will give an error (ref. https://github.com/r-spatial/sf/issues/1792#issuecomment-918660319)
dtbl_merged_copy = data.table::copy(dtbl_merged[, !'ID'])
colnames(dtbl_merged_copy) = glue::glue("{1:length(colnames(dtbl_merged_copy))}_{colnames(dtbl_merged_copy)}")

# convert to sf
dtbl_merged_sf = sf::st_as_sf(dtbl_merged_copy, wkt = '31_geom_txt', crs = sf::st_crs(unq_geoms))

# write .shp
name_shp_geom = 'gcp10_met_modis'
DIR_shp = file.path(DIR_SAVE, name_shp_geom)
if (!dir.exists(DIR_shp)) dir.create(DIR_shp)
sf::st_write(obj = dtbl_merged_sf, dsn = file.path(DIR_shp, glue::glue("{name_shp_geom}.shp")), driver = "ESRI Shapefile", quiet = F, append = T)


#----------------------------------
# visualize the data
mapview::mapview(dtbl_merged_sf, zcol = '9_soil', layer.name = 'soil_moisture')

